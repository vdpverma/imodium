<div class="BigBluePromoContainer">
  <div class="CallOut">
    <h4 class="CallOutHeading"><?php print $title; ?></h4>
    <div class="CallOutBottom"></div>
  </div>
  <div class="clearall"></div>
  <div class="rightContent">
    <h5><?php print $field_validity_rendered; ?></h5>
    <?php print $field_body_rendered; ?>
  </div>
  <div class="clearall"></div>
  <?php print $contextual; ?>
</div>
