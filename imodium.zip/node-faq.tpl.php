<div>
  <div class="headingGray"><?php print $title; ?></div>
  <?php print $field_body_rendered; ?>
  <?php print $contextual; ?>
</div>