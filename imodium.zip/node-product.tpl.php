<div class="productImage">
  <?php print $field_image_rendered; ?>
</div>
<div class="productDetails">
  <h3 class="productTitle"><?php print $field_title_rendered; ?></h3>
  <span class="tab-description"><?php print $field_short_description_rendered; ?></span>
  <?php print $field_body_rendered; ?>
</div>
<div class="clearall"></div>
<?php print $contextual; ?>