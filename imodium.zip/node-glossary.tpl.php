<tr>
  <td class="phrase"><?php print $title; ?></td>
  <td class="phraseMeaning">
    <?php print $field_body_rendered; ?>
    <?php print $contextual; ?>
  </td>
</tr>