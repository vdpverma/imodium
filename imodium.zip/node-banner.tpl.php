<div class="bannerLeft">
  <h1><?php print $field_title_rendered; ?></h1>
  <div class="bannerContent">
    <?php print $body; ?>
  </div>
  <?php print $field_page_rendered; ?>
  <?php print $contextual; ?>
</div>