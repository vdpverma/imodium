<div class="promosSection">
<?php print $field_big_banner_rendered; ?>
  <?php print $field_homepage_promo_rendered; ?>
  <div class="clearall"></div>   
  <?php print $contextual; ?>      
</div>