<div class="BluePromoContainer">
  <div class="CallOut">
    <h4 class="CallOutHeading"><?php print $title; ?></h4>
    <div class="CallOutBottom"></div>
  </div>
  <div class="rightContent">
    <h5><?php print t("True or False?"); ?></h5>
    <?php print $field_body_rendered; ?>
    <?php print $field_page_rendered; ?>
  </div>
  <div class="clearall"></div>
  <div class="BluePromoContainerBottom"></div>
  <?php print $contextual; ?>
</div>
<div class="clearall"></div>
